


<div class="left-sidebar bg-black-300 box-shadow ">
                        <div class="sidebar-content">
                            <div class="user-info closed">
                                
                            </div>
                            <!-- /.user-info -->

                            <div class="sidebar-nav">
                                <ul class="side-nav color-gray">
                                    <li class="nav-header">
                                        <span class=""></span>
                                    </li>
                                    <li>
                                        <a href="dashboard.php"><i class="fa fa-book"></i> <span>DASHBOARD</span> </a>
                                     
                                    </li>

                                    <li class="nav-header">
                                        <span class=""></span>
                                    </li>
                                    <li class="has-children">
                                        <a href="#"><i class="fa fa-gears"></i> <span>STUDENT DEPARTMENT</span> <i class="fa fa-angle-right arrow"></i></a>
                                        <ul class="child-nav">
                                            <li><a href="create-class.php"><i class="fa fa-bars"></i> <span>CREATE DEPARTMENT</span></a></li>
                                            <li><a href="manage-classes.php"><i class="fa fa fa-server"></i> <span>MANAGE DEPARTMENT</span></a></li>
                                           
                                        </ul>
                                    </li>
  <li class="has-children">
                                        <a href="#"><i class="fa fa-file-text"></i> <span>COURSE</span> <i class="fa fa-angle-right arrow"></i></a>
                                        <ul class="child-nav">
                                            <li><a href="create-subject.php"><i class="fa fa-bars"></i> <span>CREATE COURSE</span></a></li>
                                            <li><a href="manage-subjects.php"><i class="fa fa fa-server"></i> <span>MANAGE COURSE</span></a></li>
                                           <li><a href="add-subjectcombination.php"><i class="fa fa-newspaper-o"></i> <span>ADD CREDIT COURSE </span></a></li>
                                           <a href="manage-subjectcombination.php"><i class="fa fa-newspaper-o"></i> <span>MANAGE CREDIT COURSE</span></a></li>
                                        </ul>
                                    </li>
   <li class="has-children">
                                        <a href="#"><i class="fa fa-users"></i> <span>STUDENTS</span> <i class="fa fa-angle-right arrow"></i></a>
                                        <ul class="child-nav">
                                            <li><a href="add-students.php"><i class="fa fa-bars"></i> <span>ADD STUDENTS</span></a></li>
                                            <li><a href="manage-students.php"><i class="fa fa fa-server"></i> <span>MANAGE STUDENTS</span></a></li>
                                           
                                        </ul>
                                    </li>
<li class="has-children">
                                        <a href="#"><i class="fa fa-info-circle"></i> <span>RESULT</span> <i class="fa fa-angle-right arrow"></i></a>
                                        <ul class="child-nav">
                                            <li><a href="add-result.php"><i class="fa fa-bars"></i> <span>ADD RESULT</span></a></li>
                                            <li><a href="manage-results.php"><i class="fa fa fa-server"></i> <span>MANAGE RESULT</span></a></li>
                                           
                                        </ul>
                                        <li><a href="change-password.php"><i class="fa fa fa-server"></i> <span> ADMIN CHANGE PASSWORD</span></a></li>
                                           
                                    </li>
                            </div>
                            <!-- /.sidebar-nav -->
                        </div>
                        <!-- /.sidebar-content -->
                    </div>